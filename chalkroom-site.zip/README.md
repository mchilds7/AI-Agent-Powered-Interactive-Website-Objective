# Chalkroom

One integrated website: a team of AI subject assistants, plus a chatbot that controls the whole site by typing or voice.

## Files (put all of them in the same folder)
- `index.html`: every page of the site
- `styles.css`: design
- `data.js`: assignments, products, backgrounds, charts data, media file names (edit this to change content)
- `app.js`: home router and the seven subject assistants
- `pages.js`: assignments activities, dashboard, security, contact
- `control.js`: the chatbot and its AI agents
- `chalkroom-intro.mp4`, `chalkroom-intro.jpg`, `chalkroom-intro.vtt`, `chalkroom-theme.mp3`: original media

## Publish on GitHub Pages
Upload every file to the root of the repository, then go to Settings > Pages, choose the `main` branch and `/ (root)`.

## Use your own movie
Upload your file (for example `echo-movie.mp4`) and set `movie: 'echo-movie.mp4'` in the `media` line of `data.js`.
